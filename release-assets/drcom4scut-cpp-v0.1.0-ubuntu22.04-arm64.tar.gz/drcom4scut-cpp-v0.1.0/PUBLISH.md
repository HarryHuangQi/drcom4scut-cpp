# 发布到 GitHub

## 1. 创建源码仓库

在本目录执行：

```bash
git init
git add .
git commit -m "Release drcom4scut-cpp v0.1.0"
git branch -M main
git remote add origin https://github.com/YOUR_NAME/drcom4scut-cpp.git
git push -u origin main
```

也可以先在 GitHub 网页创建空仓库，再按页面给出的 remote 命令推送。

## 2. 创建 Release

Release 标签建议使用：

```text
v0.1.0
```

正文可直接使用 `RELEASE-NOTES.md`。上传 `release-assets` 中的：

```text
drcom4scut-cpp-v0.1.0-source.tar.gz
drcom4scut-cpp-v0.1.0-ubuntu22.04-x86_64.tar.gz
drcom4scut-cpp-v0.1.0-ubuntu22.04-arm64.tar.gz
SHA256SUMS
```

安装了 GitHub CLI 时可执行：

```bash
gh release create v0.1.0 \
  release-assets/drcom4scut-cpp-v0.1.0-source.tar.gz \
  release-assets/drcom4scut-cpp-v0.1.0-ubuntu22.04-x86_64.tar.gz \
  release-assets/drcom4scut-cpp-v0.1.0-ubuntu22.04-arm64.tar.gz \
  release-assets/SHA256SUMS \
  --title "drcom4scut-cpp v0.1.0" \
  --notes-file RELEASE-NOTES.md
```

## 3. 发布前检查

```bash
rg 'password=|username=|mac=|ip=' . \
  --glob '!release-assets/*.tar.gz' \
  --glob '!bin/drcom4scut-*'
sha256sum -c release-assets/SHA256SUMS
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j2
ctest --test-dir build --output-on-failure
```

检查搜索结果只包含空模板、占位说明和测试账号。不要发布个人配置、日志或抓包。
