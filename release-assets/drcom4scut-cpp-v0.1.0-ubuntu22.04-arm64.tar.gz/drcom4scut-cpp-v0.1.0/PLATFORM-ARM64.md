# ARM64 发布包

此包在目标 ARM64 Ubuntu/Jetson 上从源码编译：

```bash
sudo bash install-ubuntu22.04-arm64.sh
```

Jetson Linux 可运行 sudo bash install-jetson-nano.sh。
